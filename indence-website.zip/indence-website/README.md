# Indence website recreation

Open `index.html` in a browser.

Pages:
- `index.html` - homepage / hero
- `what-we-do.html` - engagement models
- `capabilities.html` - capabilities grid
- `our-approach.html` - three foundations + strategy-to-scale process
- `about.html` - about page starter

The supplied reference screenshot was used for the visual direction and the globe area was extracted as a local asset.
