
const icons={
globe:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><circle cx="24" cy="24" r="20"/><path d="M4 24h40M24 4c6 5 9 12 9 20s-3 15-9 20M24 4c-6 5-9 12-9 20s3 15 9 20M7 13c5 3 11 4 17 4s12-1 17-4M7 35c5-3 11-4 17-4s12 1 17 4"/></svg>`,
people:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.35"><circle cx="17" cy="17" r="6"/><circle cx="31" cy="17" r="6"/><path d="M5 39c1-7 5-11 12-11s11 4 12 11M19 39c1-7 5-11 12-11s11 4 12 11"/></svg>`,
layers:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="m24 5 18 10-18 10L6 15 24 5Z"/><path d="m6 24 18 10 18-10M6 33l18 10 18-10"/></svg>`,
chart:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="M7 40h35M10 37V27M20 37V20M30 37V13M40 37V7"/><path d="m8 21 9-7 8 4 12-12"/></svg>`,
building:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="M8 41V13l16-6v34M24 41V18l16-5v28M14 18v4M14 27v4M30 23v4M37 21v4M30 32v4M37 30v4"/><path d="M5 41h38"/></svg>`,
target:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><circle cx="24" cy="24" r="17"/><circle cx="24" cy="24" r="9"/><circle cx="24" cy="24" r="2"/><path d="M24 2v8M24 38v8M2 24h8M38 24h8"/></svg>`,
shield:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="M24 5 40 11v12c0 10-6 16-16 20C14 39 8 33 8 23V11l16-6Z"/><path d="m16 24 5 5 11-12"/></svg>`,
dna:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="M13 5c0 9 22 9 22 19S13 33 13 43M35 5c0 9-22 9-22 19s22 9 22 19"/><path d="M16 12h16M13 20h22M13 28h22M16 36h16"/></svg>`,
document:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="M11 4h20l8 8v32H11V4Z"/><path d="M31 4v9h8M17 22h16M17 29h16M17 36h11"/></svg>`,
flask:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="M18 5h12M21 5v15L10 39c-1 2 1 4 4 4h20c3 0 5-2 4-4L27 20V5"/><path d="M15 33h18"/></svg>`,
star:`<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.25"><path d="m24 4 5.8 12.1L43 18l-9.5 9.2L35.8 40 24 33.7 12.2 40l2.3-12.8L5 18l13.2-1.9L24 4Z"/></svg>`,
menu:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 7h16M4 12h16M4 17h16"/></svg>`
};
document.querySelectorAll("[data-icon]").forEach(e=>{if(icons[e.dataset.icon])e.innerHTML=icons[e.dataset.icon]});
const btn=document.querySelector(".mobile-menu"),nav=document.querySelector(".nav");
if(btn)btn.onclick=()=>{nav.style.display=nav.style.display==="flex"?"":"flex";nav.style.position="absolute";nav.style.top="70px";nav.style.right="20px";nav.style.height="auto";nav.style.flexDirection="column";nav.style.alignItems="stretch";nav.style.gap="0";nav.style.padding="8px 18px";nav.style.background="#03070d";nav.style.border="1px solid #29313a";nav.style.transform="none"};
